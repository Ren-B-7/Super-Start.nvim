require("config.lazy")
require("opts")
require("keymaps")
require("autocmd")
