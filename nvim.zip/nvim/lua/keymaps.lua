local set = vim.keymap.set
local cmd = vim.cmd

set("n", "<leader>pv", cmd.Ex)
set("n", "<C-q>", ":w<cr> :bd<cr> :NvimTreeFocus<cr>")

-- undo tree
-- "u" - means undo
-- <c-r> - means redo
set("n", "<leader>u", cmd.UndotreeToggle)

-- telescope keymaps
local builtin = require("telescope.builtin")

set("n", "<leader>pf", builtin.find_files, {})
set("n", "<C-g>", builtin.git_files, {})
set("n", "<leader>ps", function()
	builtin.grep_string({ search = vim.fn.input("Grep > ") })
end)

-- harpoon keymaps
local mark = require("harpoon.mark")
local ui = require("harpoon.ui")
local term = require("harpoon.term")
set("n", "<leader>c", ui.toggle_quick_menu, {})
set("n", "<leader>a", mark.add_file, {})
set("n", "<C-j>", ui.nav_next, {})
set("n", "<C-k>", ui.nav_prev, {})
set("n", "<C-t>", function()
	term.gotoTerminal(1)
end)

-- lsp keymaps
local lsp = vim.lsp.buf

set("n", "gd", lsp.definition)
set("n", "K", lsp.hover)
set("n", "<leader>vws", lsp.workspace_symbol)
set("n", "<leader>vd", vim.diagnostic.open_float)
set("n", "[d", vim.diagnostic.goto_next)
set("n", "]d", vim.diagnostic.goto_prev)
set("n", "<leader>vca", lsp.code_action)
set({ "n", "v", "s" }, "<leader>vrr", lsp.references)
set({ "n", "v", "s" }, "<leader>vrn", lsp.rename)

function _G.set_terminal_keymaps()
	local opts = { buffer = 0 }
	set("t", "<esc>", [[<C-\><C-n>]], opts)
	set("t", "jk", [[<C-\><C-n>]], opts)
	set("t", "<C-h>", [[<Cmd>wincmd h<CR>]], opts)
	set("t", "<C-j>", [[<Cmd>wincmd j<CR>]], opts)
	set("t", "<C-k>", [[<Cmd>wincmd k<CR>]], opts)
	set("t", "<C-l>", [[<Cmd>wincmd l<CR>]], opts)
	set("t", "<C-w>", [[<C-\><C-n><C-w>]], opts)
end

-- if you only want these mappings for toggle term use term://*toggleterm#* instead
cmd("autocmd! TermOpen term://* lua set_terminal_keymaps()")

-- file tree
set({ "t", "c", "v", "n" }, "<leader>e", ":NvimTreeToggle<cr>", {})
set({ "v", "n", "t" }, "<leader>h", "<C-\\><C-N><C-w>h", {})
set({ "v", "n", "t" }, "<leader>j", "<C-\\><C-N><C-w>j", {})
