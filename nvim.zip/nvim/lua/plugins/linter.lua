return {
	{
		"mfussenegger/nvim-lint",
		name = "nvim-lint",
	},
	{
		"rshkarin/mason-nvim-lint",
		name = "linter",
		dependencies = {
			"williamboman/mason.nvim",
			"williamboman/mason-lspconfig.nvim",
		},

		config = function()
			require("lsp-zero").setup()
			require("mason").setup()

			ensure_installed = {
				"checkstyle",
				"gitlint",
				"biome",
				"luacheck",
				"pylint",
				"cpplint",
			}
			automatic_installation = true
		end,
	},
}
