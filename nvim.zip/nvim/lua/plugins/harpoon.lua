return {
   "ThePrimeagen/harpoon",
   lazy = true,
   dependencies = "nvim-lua/plenary.nvim",
}
