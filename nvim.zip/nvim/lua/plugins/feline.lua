return {
	"feline-nvim/feline.nvim",
	config = function()
		require("feline").setup()
	end,
}
