return {
	"nvim-treesitter/nvim-treesitter-textobjects",
	event = "VeryLazy",
	enabled = true,
	lazy = false,
	dependencies = { "nvim-treesitter/nvim-treesitter" },
}
