vim.api.nvim_create_autocmd("TextYankPost", {
	callback = function()
		vim.highlight.on_yank({})
	end,
	desc = "highlights yank",
})
vim.api.nvim_create_autocmd("BufWinEnter", {
	callback = function()
		local view = require("plugins/nvim_tree")
		view.signcolumn = "no"
		view.numbers = true
		view.relativenumber = true
	end,
	desc = "reload line numbers",
})
