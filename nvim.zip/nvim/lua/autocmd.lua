local nvim_create = vim.api.nvim_create_autocmd
nvim_create("TextYankPost", {
	callback = function()
		vim.highlight.on_yank({})
	end,
	desc = "highlights yank",
})
nvim_create("BufWinEnter", {
	callback = function()
		local view = require("plugins/nvim_tree")
		view.signcolumn = "no"
		view.numbers = true
		view.relativenumber = true
		view.modifiable = true
	end,
	desc = "reload line numbers",
})
